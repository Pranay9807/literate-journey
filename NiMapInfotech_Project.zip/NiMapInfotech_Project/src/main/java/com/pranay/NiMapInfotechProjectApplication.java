package com.pranay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NiMapInfotechProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(NiMapInfotechProjectApplication.class, args);
	}

}
