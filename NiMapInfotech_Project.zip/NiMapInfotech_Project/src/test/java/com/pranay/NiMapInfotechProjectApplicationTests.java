package com.pranay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NiMapInfotechProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
